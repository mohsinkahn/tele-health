import Detailinformation from '@/components/Detailinformation';

export default function DetailinformationPage() {
  return (
    <main className="">
      <Detailinformation />
    </main>
  );
}
